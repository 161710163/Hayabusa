<?php $__env->startSection('konten1'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center><h1>
Selamat Datang di Menu Utama
</h1></center>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>