	<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

         
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
<link href="/Bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="/Bootstrap/dist/css/bootstrap.css" rel="stylesheet">
<link href="/Bootstrap/dist/css/bootstrap-theme.css" rel="stylesheet">
<link href="/Bootstrap/dist/css/bootstrap-theme.min.css" rel="stylesheet">

 <style>
            html, body {
            	margin: 0;
            	padding: 0;
            	height: 100%;
            	font: 13px Arial;
                
}
.wrapper{
	min-height: 100%;
	position: relative;

}
.header{
	            background-color: #f0f0f0;
	            padding: 5px;
	            height: 50px;
	            color: #0000ff;
    
}

    
           
        </style>
    </head>

    <body>
<div class="header">
<font color="Blue">                   
                   <ul class="nav nav-tabs">
  <li role="presentation"><a href="konten">Menu Utama</a></li>
  <li role="presentation"><a href="konten1">Gallery Persib</a></li>
  <li role="presentation"><a href="konten2">Data Pemain </a></li>
					</ul> 

     </font>
 </div>
</body>
</html>