<?php $__env->startSection('konten3'); ?>
22
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>