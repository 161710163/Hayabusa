<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
<link href="/Bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="/Bootstrap/dist/css/bootstrap.css" rel="stylesheet">
<link href="/Bootstrap/dist/css/bootstrap-theme.css" rel="stylesheet">
<link href="/Bootstrap/dist/css/bootstrap-theme.min.css" rel="stylesheet">

           </head>
    <body>


                   
                   <ul class="nav nav-tabs">
  <li role="presentation" class="active">  <a href="https://laracasts.com">Laracasts</a></li>
  <li role="presentation"><a href="https://laravel.com/docs">Documentation</a></li>
  <li role="presentation"><a href="https://laravel-news.com">News</a></li>
					</ul> 
        
    </body>
</html>
