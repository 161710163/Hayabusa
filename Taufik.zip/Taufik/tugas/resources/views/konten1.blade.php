@extends('layouts.master')
@section('konten')
Selamat Datang Di Menu Utama
@endsection