<!DOCTYPE html>
<html>
<head>
	<title>Latihan Template</title>
</head>
<body>
		@include('template.header')<br>
			@yield('konten3')<br>
		@include('template.footer')
		</body>
</html>