<!DOCTYPE html>
<html>
<head>
	<title>Latihan Template</title>
</head>
<body>
		@include('template.header')<br>
			@yield('konten2')<br>
		@include('template.footer')
		</body>
</html>