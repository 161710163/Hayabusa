@extends('layouts.master2')
@section('konten2')
Biodata
@endsection