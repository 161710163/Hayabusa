<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JunikaController extends Controller
{
    //
}
