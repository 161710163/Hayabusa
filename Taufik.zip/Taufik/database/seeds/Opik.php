<?php

use Illuminate\Database\Seeder;

class sugiantoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
                 $a=[
              ['Nis'=>'123',
              'Nama'=>'Taufik',
              'Tempat_lahir'=>'Soreang',
              'Tanggal_lahir'=>'2001-04-12',
              'Alamat'=>'bandung',
              'Cita_cita'=>'dokter',
              'hobi'=>'bulu tangkis',
              'photo'=>'tidak ada']
              ];
                DB::table('siswas')->insert($a);
             
    }
}
