<?php

use Illuminate\Database\Seeder;

class agung extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
 $a=[
              ['Nis'=>'123',
              'Nama'=>'Opik',
              'Tempat_lahir'=>'Bandung',
              'Tanggal_lahir'=>'2001-04-12',
              'Alamat'=>'bandung',
              'Cita_cita'=>'Hacker',
              'Hobi'=>'bulu tangkis',
              'Photo'=>'tidak ada']
              ];
                DB::table('siswas')->insert($a);
    }
}
