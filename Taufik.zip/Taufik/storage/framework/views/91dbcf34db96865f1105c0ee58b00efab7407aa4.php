<?php $__env->startSection('e'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
  <div class="page-header">
      <center><h1>BIOGRAFI</h1></center> 
      </div>
     <center><div class="row">
        <div class="col-sm-4">
          <div class="panel panel-info">
            <div class="panel-heading">
              <h3 class="panel-title">Maldini Pali</h3>
            </div>
            <div class="panel-body">
              Nama : Maldini Pali
Tempat dan tanggal Lahir : Mamuju, Sulawesi Barat, 27 Januari 1995
Nama Orang tua :
- Ayah : Paulus Pangloli Pali
- Ibu : Ester Tambing, yang sampai sat ini masih berdomisili di Mamuju
Tinggi badan : 172 Cm
Posisi dalam Timnas U-19: triker sayap kanan pola 4-3-3
Nomor Jersey : 15
SSB :
- School of Exellent PSSI, Indonesia Football Academy
- Leicester City, Inggris. Dia juga menjadi bagian tim
- Sociedad Anonima Deportiva (SAD) Uruguay.
Klub Favorit : Barcelona


Jika anda berpikir nama winger tim nasional U-19, Maldini, dicatut dari nama bek legendaris AC Milan, Paolo Maldini, yah.. berarti memang benar.

“Yang memberi nama itu ayahnya. Dia tergila-gila sepak bola,” tutur ibu Maldini, Esther, kepada Tribunnews.com setelah Indonesia mengalahkan Timor Leste di Gelora Delta Sidoarjo, Jumat (20/9/2013).

Maldini-Pali-di-Piala-AFF-U-19-2013Sang ayah sepertinya mengendus talenta Maldini dalam bermain sepak bola. Ayahnya kemudian menjadi pelatih pertama mantan pemain Deportivo Indonesia itu.

“Ayahnya dulu pemain di kampung. Dia yang melatih Maldini,” kata Esther yang datang dari Mamuju, Sulawesi Barat, untuk melihat Maldini bermain.

Pemain yang dikenal lincah dengan tinggi badan 172 ini adalah putra sulung pasangan Paulus Pangloli Pali dan Ester Tambing. Maldini merupakan satu dari empat pemain produk school of excellen PSSI,Indonesia Football Academy (IFA) yang dikirim menimba ilmu sepakbola di klub anggota champions league Inggris, Leicester City. Tiga pemain jebolan IFA lainnya adalah Yogi Rahadian, Mohammad Fahmi Al Ayyubi dan Rico Adrianto.

Maldini Pali, adalah salah satu dari sekian banyak talenta emas di Timnas Indonesa U-19. Namun Maldini tidak akan sebaik sekarang tanpa peran Muhammad Irfan Rahman, pelatih yang pertama kali mengasah kemampuan Maldini.

Muhammad Irfan Rahman, menemukan Maldini ketika masih duduk di bangku kelas II SMP. Ketika itu Maldini mengikuti Liga Tasha, kompetisi sepakbola di tingkat lokal Sulbar U-14.

“Saat itu Maldini belum menonjol, justru banyak teman-temannya yang lebih bagus main,” kata Irfan di Mamuju, seperti dilansir Radar Sulbar, Senin (22/9).

Meski kurang menonjol, Maldini punya keinginan kuat untuk maju. Ia minta dilatih secara privat selama beberapa bulan. Akhirnya kekurangan Maldini, seperti passing, dribling, dan kontrol bola itu bisa ditutupi latihan privat.

“Selama privat saya ajari dia tentang kecepatan, dasar-dasar main bola, dan ketahanan fisik. Pernah satu bulan full saya ‘siksa’ dia di lapangan. Dia pantang menyerah dan sabar,” ungkapnya.

Setelah mulai bagus, Maldini diikutkan Piala Suratin di Sinjai Sulawesi Selatan. Setelah Piala Suratin, pihak SSB Hasanuddin Makassar datang memanggil Maldini untuk mengikuti Turnamen Wakli Kota Cup U-15 di Makassar.

Alhasil, Maldini menjadi pencetak gol terbanyak dan menjadi best player. “Golnya kalau tidak salah 14,” kenang Irfan.

Setelah turnamen itu, Maldini rupanya dipantau dan ditunjuk mewakili Sulsel dalam piala Menpora U-15 di Jakarta. Karena Sulbar tidak ikut saat itu, Maldini bersama dua anak asuhnya yang lain dipinjam Sulsel.

Saat ada pembentukan Indonesia Footbal Academi (IFA), tiga anak didik Irfan dari Mamuju terpilih ikut seleksi. Mereka adalah Maldini, Alfuad, dan Ahmad Alamsyah. Tapi yang lolos untuk bergabung di IFA hanya Maldini dan Alfuad.

“Nah, pada saat itu Maldini dan Alfuad diikutkan dalam seleksi Timnas U-16 di Uzbekistan, dan yang lolos hanya Maldini,” terang Irfan.

Satu tahun kemudian, Maldini terpilih menjadi salah satu dari tiga utusan Indonesia untuk berlatih di Leicester City, Inggris, selama tiga bulan. Dari Leicester, IFA dibubarkan, Maldini kemudian ditawati untuk dikontrak beberapa klub besar tanah air, seperti; Persija, Arema, Persib Bandung, dan Pelita Jaya.

Maldini-Pali-Dan-Teman

Namun Maldini memilih Pelita Jaya. Dia dikontrak selama tiga tahun, dengan gaji Rp 3 juta per bulan. Saat dia main di Pelita Jaya, Maldini terpilih lagi untuk berlatih di Uruguay selama dua tahun.

“Maldini kemudian pulang ke Mamuju tanggal 10 Agustus 2013. Maldini minta supaya saya latih secara privat. Tapi baru dua hari berjalan, Maldini dipanggil pulang ke Jakarta oleh Yeyen Tumena (mantan pemain Timnas Indonesia) untuk ikut seleksi Timnas U-19 persiapan AFF. Hanya empat orang alumni SAD Uruguay yang lolos, salah satunya Maldini,” ungkapnya.

Hal yang membuat Irfan terharu adalah Maldini tak melupakan dirinya. Sampai sekarang, sebelum main Maldini selalu menelpon Irfan.

Irfan mengaku Maldini mengajaknya ke Surabaya. Maldini mau tanggung biaya transpor pulang pergi. Tapi di saat bersamaan, Irfan membela Tim PWI Sulbar di Porwanas Banjarmasin.

“Pesan saya untuk Maldini, jangan cepat puas. Berlatih terus, tutupi kekurangan, jaga kesehatan dan jangan lupa berdoa,” harap Irfan.
            </div>
          </div>
          </center> 
</body>
</html>
<br><br><br><br><br><br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.master5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>