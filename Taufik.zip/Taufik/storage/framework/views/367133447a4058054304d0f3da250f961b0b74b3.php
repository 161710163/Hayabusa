<?php $__env->startSection('halaman4'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
     <div class="page-header">
       <center><h1>Pesan Presiden Republik Indonesia</h1></center> 
      </div>
      <div class="row">
        <div class="col-sm-4">
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3 class="panel-title">Presiden Pertama Soekarno RI</h3>
            </div>
            <div class="panel-body">
              "Gantungkan cita-citamu setinggi langit! Bermimpilah setinggi langit. Jika engkau jatuh, engkau akan jatuh di antara bintang-bintang."
            </div>
          </div>
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title">Presiden Kedua Soeharto RI</h3>
            </div>
            <div class="panel-body">
              "Kalau kamu ingin menjadi pribadi yang maju, kamu harus pandai mengenal apa yang terjadi, pandai melihat, pandai mendengar, dan pandai menganalisis."
            </div>
          </div>
        </div><!-- /.col-sm-4 -->
        <div class="col-sm-4">
          <div class="panel panel-success">
            <div class="panel-heading">
              <h3 class="panel-title">Presiden Ketiga Bacharuddin Jusuf Habibie RI</h3>
            </div>
            <div class="panel-body">
              "Hanya sumber daya manusia yang ahli dan produktif saja yang dapat menghadapi tantangan dan memecahkan masalah."

            </div>
          </div>
          <div class="panel panel-info">
            <div class="panel-heading">
              <h3 class="panel-title">Presiden Kelima Megawati Sukarnoputri RI</h3>
            </div>
            <div class="panel-body">
              "Kebahagiaan itu bukan karena berkoalisi dengan kekuasaan, tapi kebahagiaan itu akan datang ketika kita bisa menangis dan tertawa bersama."

              <center></div>
          </div>
          <div class="panel panel-danger">
            <div class="btn btn-danger">
              <h3 class="panel-title">Presiden Keemapat Abdurrahman Wahid RI</h3>
            </div>
            <div class="panel-body">
          "Kalau ingin melakukan perubahan jangan tunduk terhadap kenyataan, asalkan kau yakin di jalan yang benar maka lanjutkan."
</center>
            </div>
          </div>
        </div><!-- /.col-sm-4 -->
        <div class="col-sm-4">
          <div class="panel panel-warning">
            <div class="panel-heading">
              <h3 class="panel-title">Presiden Keenam Susilo Bambang Yudhoyono RI</h3>
            </div>
            <div class="panel-body">
             "Bila pemimpin terlalu tangan besi, demokrasi kita akan mati. Bila dibiarkan dengan dalih kebebasan, negeri ini bisa menjadi lautan anarki."

            </div>
          </div>
          <div class="panel panel-danger">
            <div class="panel-heading">
              <h3 class="panel-title">Presiden Ketujuh Joko Widodo RI</h3>
            </div>
            <div class="panel-body">
           "Kehormatan hidup bukanlah ditentukan seberapa tinggi pendidikan, seberapa banyak ijazah akademismu, seberapa banyak bintang-bintang jasa bertaburan di dadamu, tapi kehormatan hidup itu ada ketika namamu melekat di hati orang-orang sekitarmu, kerjamu bermanfaat untuk rakyat banyak, dan doamu tiap bangun tidur memohon agar hari ini lebih baik dari hari kemarin."
           

            </div>
          </div>
        </div><!-- /.col-sm-4 -->
      </div>


</body>
</html>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><b
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>