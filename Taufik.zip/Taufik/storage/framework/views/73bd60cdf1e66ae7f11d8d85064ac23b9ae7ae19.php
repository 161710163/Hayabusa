<?php $__env->startSection('content'); ?>
<font color="Blue">  
                 <ul class="nav nav-tabs">
  <li role="presentation"><a href="halaman"><button type="button" class="btn btn-default">Menu Utama</button></a></li>
  <li role="presentation"><a href="halaman1"><button type="button" class="btn btn-primary">Gallery</button></a></li>
  <li role="presentation"><a href="halaman2"><button type="button" class="btn btn-success">Data Table</button></a></li>
  <li role="presentation"><a href="halaman3"><button type="button" class="btn btn-info">Inspirasi</button></a></li>
  <li role="presentation"><a href="halaman4"><button type="button" class="btn btn-warning">paragraph</button></a></li>
  <li role="presentation"><a href="halaman5"><button type="button" class="btn btn-danger">free</button></a></li>
 
          </ul> 
      
     </font>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>