<!DOCTYPE html>
<html>
<head>
	<title>Latihan Template</title>
</head>
<body>
		<?php echo $__env->make('template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?><br>
			<?php echo $__env->yieldContent('d'); ?><br>
		<?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</body>
</html>