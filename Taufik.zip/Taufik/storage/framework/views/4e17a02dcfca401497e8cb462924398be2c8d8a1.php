<?php $__env->startSection('d'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
     <div class="page-header">
       <center><h1>Karakter Utama ONE PIECE</h1></center> 
      </div>
      <div class="row">
        <div class="col-sm-4">
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title">Luffy D'monkey</h3>
            </div>
            <div class="panel-body">
              "Tokoh Utama yang bercita-cita menjadi raja bajak laut setelah Shank si rambut merah singgah di pulau kelahirannya, Fusha, ia diberikan topi jerami olehnya sehingga kelak ia harus mengembalikannya jika bertemu lagi. Topi jerami inilah yang kemudian menjadi ciri khasnya. Pemakan buah gomu-gomu, dapat membuat seluruh anggota tubuhnya melar seperti karet, tidak tertembus peluru dan anti listrik, tetapi sangat lemah terhadap senjata tajam."
            </div>
          </div>
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title">Vinsmoke Sanji</h3>
            </div>
            <div class="panel-body">
              "Koki yang bercita-cita menemukan lautan legendaris di mana semua sumber bahan makanan berasal, All Blue. Ia juga merupakan murid dari Zeff si Kaki Merah, koki handal dari Restoran Baratie yang dulunya bajak laut. Sanji menggunakan kedua kakinya untuk bertarung dan tidak pernah menggunakan tangannya karena menurutnya, tangan adalah harta karun bagi seorang koki."
            </div>
          </div>
        </div><!-- /.col-sm-4 -->
        <div class="col-sm-4">
          <div class="panel panel-danger">
            <div class="panel-heading">
              <h3 class="panel-title">Toni Chopper</h3>
            </div>
            <div class="panel-body">
              "Dokter yang berwujud rusa kutub super yang memppunyai tujuh wujud perubahan berhidung biru yang mengemban keinginan dari dokter terhebat di dunia dokter Hiluluk, yang bercita-cita menyembuhkan segala penyakit yang ada di dunia. Dia pemakan buah hito-hito sehingga dapat berbicara layaknya manusia. Chopper menggunakan rumble ball ketika bertarung."

            </div>
          </div>
          <div class="panel panel-danger">
            <div class="panel-heading">
              <h3 class="panel-title">Nami</h3>
            </div>
            <div class="panel-body">
              "Navigator handal yang mampu merasakan perubahan cuaca dengan tubuhnya, ia juga merupakan pencuri walaupun setelah bergabung dengan Luffy kemampuan ini masih sering digunakan. Bercita-cita menggambar peta dunia. Nami juga dapat bertarung menggunakan Perfect Clima Tact buatan Usopp."

              <center></div>
          </div>
        </div><!-- /.col-sm-4 -->
       

</body>
</html>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><b
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.master4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>