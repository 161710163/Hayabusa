<?php $__env->startSection('halaman2'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Waktu Di Garut</title>
</head>

<body>
<center><h2>WAKTU DI GARUT</h2>
<?php
$image=glob("gambar/7.jpg");
$gg=glob("gambar/8.jpg");
$ww=glob("gambar/9.jpg");
$aa=glob("gambar/12.jpg");
$zz=glob("gambar/10.jpg");
$app=glob("gambar/11.jpg");
for($i=0;$i<count($image);$i++)
for($i=0;$i<count($gg);$i++)
for($i=0;$i<count($zz);$i++)	
for($i=0;$i<count($app);$i++)	

{
	$single_image = $image[$i];
	$double = $gg[$i];
	$three = $ww[$i];
	$four = $aa[$i];
	$five = $zz[$i];
	$six = $app[$i];
?>
	<img src="<?php echo $single_image;?>" width="360" heigth="260"/?>
	<img src="<?php echo $double;?>" width="360" heigth="260"/?>
	<img src="<?php echo $three;?>" width="360" heigth="260"/?>
	<img src="<?php echo $four;?>" width="360" heigth="260"/?>
	<img src="<?php echo $five;?>" width="360" heigth="260"/?>
	<img src="<?php echo $six;?>" width="360" heigth="260"/?>
	<?php
}
	?>
</center>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>