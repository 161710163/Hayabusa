<?php $__env->startSection('e'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
  <div class="page-header">
      <center><h1>TERORIS</h1></center> 
      </div>
     <center><div class="row">
          <div class="panel panel-info">
            <div class="panel-heading">
              <h3 class="panel-title">Deidara</h3>
            </div>
            <div class="panel-body">
Deidara (デイダラ, Deidara) adalah Ninja Pelarian dari Iwagakure. Selama waktunya di desa, ia adalah anggota Korps Ledakan. Setelah lari dari desa, ia bergabung dengan Akatsuki dan merupakan salah satu anggotanya termuda. Di sana ia bertemu dengan Sasori sampai kematian sang rekan, dan kemudian dengan Tobi sebelum kematiannya sendiri.

Latar Belakang
Selama waktunya sebagai shinobi Iwagakure, Deidara adalah seorang murid di bawah Tsuchikage Ketiga: Ōnoki.[3] Ia memiliki kekkei genkai elemen ledakan yang memungkinkan dia untuk menjadi anggota Korps Ledakan.[4] Meskipun sangat memuji keindahan tanah liatnya, keinginan Deidara untuk mencapai ketinggian yang lebih dalam seni, mengakibatkan dia mencuri sebuah kinjutsu yang memungkinkan seseorang untuk menguleni chakra mereka menjadi zat.[1]. Menggunakan tanah liat peledak, Deidara menemukan seni yang ia inginkan: Seni dalam waktu singkat (一瞬の芸術, Isshun no Geijutsu).[1] Dalam anime, Deidara meninggalkan Iwagakure berantakan dengan meledakkan beberapa bangunan di desa.[5] Sejak itu, Deidara menjadi ninja pelarian dan menawarkan jasanya sebagai pengebom kepada pemberontak di berbagai negara.[1]

Perbuatan Deidara akhirnya menarik perhatian dari Akatsuki, lalu Itachi Uchiha, Kisame Hoshigaki, dan Sasori dikirim untuk merekrut dia setelah Orochimaru meninggalkan organisasi mereka. Deidara menolak pada awalnya sampai ia menerima tantangan dari Itachi pada kondisi bahwa Akatsuki biarkan dia jika dia menang. Namun, Deidara dengan mudah dikalahkan oleh Sharingan Itachi dan bergabung dengan organisasi, yang bermitra dengan sesama seniman Sasori. Egonya hancur sejak saat itu karena ia mengaku dirinya bahwa Sharingan adalah sebuah karya seni, Deidara membawa kebencian pembunuh untuk Itachi dan Sharingan selama sisa hidupnya.[6] Mengetahui bahwa Itachi sebagai lawan yang lebih kuat, Deidara mengambil langkah selama waktu dengan Akatsuki untuk membalas dendam kepada Itachi, seperti pelatihan mata kirinya untuk melawan genjutsu,[7] dan merancang cara untuk membuat C4.[8]





            </div>
          </div>
          </center> 
</body>
</html>
<br><br><br><br><br><br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.master5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>