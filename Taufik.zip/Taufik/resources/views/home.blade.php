@extends('layouts.app')

@section('content')
<font color="Red">  
                 <ul class="nav nav-tabs">
  <li role="presentation"><a href="page"><button type="button" class="btn btn-default">Menu Utama</button></a></li>
  <li role="presentation"><a href="page2"><button type="button" class="btn btn-primary">Gallery</button></a></li>
  <li role="presentation"><a href="page3"><button type="button" class="btn btn-success">Data Table</button></a></li>
  <li role="presentation"><a href="page4"><button type="button" class="btn btn-info"> Peran Karakter One Piece</button></a></li>
  <li role="presentation"><a href="page6"><button type="button" class="btn btn-warning">paragraf</button></a></li>
  <li role="presentation"><a href="page5"><button type="button" class="btn btn-danger">Biografi</button></a></li>
 
          </ul> 	
      
     </font>

@endsection
