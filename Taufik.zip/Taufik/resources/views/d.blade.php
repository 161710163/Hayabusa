@extends('layouts.master4')
@extends('layouts.app')
@section('d')
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
     <div class="page-header">
       <center><h1>Karakter Yu Gi Oh</h1></center> 
      </div>
      <div class="row">
        <div class="col-sm-4">
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title">Yami Yugi</h3>
            </div>
            <div class="panel-body">
              "Roh tak akan musnah"

            </div>
          </div>
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title">Yugi Muto</h3>
            </div>
            <div class="panel-body">
              "Aku bertarung demi orang-orang yg kupercayai pada saat seperti apapun. Teman, Diriku sendiri, dan untuk menjadi Duelist sejati"

            </div>
          </div>
        </div><!-- /.col-sm-4 -->
        <div class="col-sm-4">
          <div class="panel panel-danger">
            <div class="panel-heading">
              <h3 class="panel-title">Tea Gardner</h3>
            </div>
            <div class="panel-body">
              "Kemarahan, kesedihan, kebencian, dan ambisi yang ada di dalam hati.. Juga musuh yang ada dalam diri kita sendiri"


            </div>
          </div>
          <div class="panel panel-danger">
            <div class="panel-heading">
              <h3 class="panel-title">Seto Kaiba</h3>
            </div>
            <div class="panel-body">
              "Seranglah aku dengan kebencian dan kemarahanmu ! Itu tak akan bisa mengalahkanku"


              <center></div>
          </div>
        </div><!-- /.col-sm-4 -->
       

</body>
</html>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><b
@endsection