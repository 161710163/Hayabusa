@extends('layouts.master6')
@extends('layouts.app')
@section('f')
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<hr class="featurette-divider">

      <div class="row featurette">
        <div class="col-md-7">
          <h2 class="featurette-heading">Kebencian:<span class="text-muted">Hate Is Dark</span></h2>
          <p class="lead">Kelemahan diriku adalah Membenci Seseorang.</p>
        </div>
        <div class="col-md-5">
          <?php
$image=glob("gambar/i.jpg");
for($i=0;$i<count($image);$i++)	
{
	$single_image = $image[$i];
?>
	<img src="<?php echo $single_image;?>" width="360" heigth="260"/?>
	<?php
}
	?>
        </div>
      </div>

      <hr class="featurette-divider">

      <div class="row featurette">
        <div class="col-md-7 col-md-push-5">
          <h2 class="featurette-heading">Cinta:<span class="text-muted">Love Is Evertyhing</span></h2>
          <p class="lead">Cinta itu Segalanya.
</p>
        </div>
        <div class="col-md-5 col-md-pull-7">
           <?php
$gg=glob("gambar/j.png");
for($i=0;$i<count($gg);$i++)	
{
	$double = $gg[$i];
?>
	<img src="<?php echo $double;?>" width="360" heigth="260"/?>
	<?php
}
	?>        </div>
      </div>

     

      <hr class="featurette-divider">

</body>
</html>
@endsection